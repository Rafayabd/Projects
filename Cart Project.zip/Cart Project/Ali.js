const addToCardAllButtons = document.querySelectorAll (".shop-item-button");
const cartItemsElement = document.querySelector (".cart-items");
const purchaseBtn = document.querySelector (".btn-purchase"); 


addToCardAllButtons.forEach(function(singleAddToCardBtn){
  singleAddToCardBtn.addEventListener("click", addtoCardBtnHandler);
});

function addtoCardBtnHandler(event){
  event.preventDefault();
  const currentElement = event.target;
  const mainShopItemDiv = currentElement.parentElement.parentElement;
  const itemName = mainShopItemDiv.querySelector (".shop-item-title").innerText;
  const itemImage = mainShopItemDiv.querySelector (".shop-item-image").src;
  const itemPrice = mainShopItemDiv.querySelector (".shop-item-price").innerText;



//Check If Some Item Is Already Exists//
  const cartItemsNames = document.querySelectorAll(".cart-item-title");

  let iscartItemIsAlreadyExists = false;
  if(cartItemsNames.length > 0){
    cartItemsNames.forEach(function(singleCartItemName){
      if(singleCartItemName.innerHTML === itemName){
        iscartItemIsAlreadyExists = true;

      }
    });
  }
  if(iscartItemIsAlreadyExists){
    alert("This Item is Already in the Cart");
    return;
  }

  //Append//
  cartItemsElement.innerHTML += `<div class="cart-row">
  <div class="cart-item cart-column">
      <img class="cart-item-image" src="${itemImage}" width="100" height="100">
      <span class="cart-item-title">${itemName}</span>
  </div>
  <span class=" cart-column">$ <span class="cart-price-item-item">${itemPrice}</span></span>
  <div class="cart-quantity cart-column">
      <input class="cart-quantity-input" type="number" value="1">
      <button class="btn btn-danger btn-remove" type="button">REMOVE</button>
  </div>
</div> `
bindcartItemRemoveButtons ();
updateCartTotal ();
bindAllCartQuantityInputFields();
}
function bindcartItemRemoveButtons(){
  const cartItemRemoveButtons = document.querySelectorAll (".btn-remove")
  cartItemRemoveButtons.forEach(function(singleRemoveBtn){
    singleRemoveBtn.addEventListener("click", singleCartItemRemoveBtnHandler);
  })
}
  function singleCartItemRemoveBtnHandler (event){
    event.preventDefault();
    const currentElement = event.target;
    if(confirm("Are You Sure")){
    currentElement.parentElement.parentElement.remove();
    updateCartTotal ();
    }
  }
  function updateCartTotal(){
    const selectAllCartPrices = document.querySelectorAll (".cart-price-item-item");
    let cartTotal = 0;
    selectAllCartPrices.forEach(function(singlePrice){
     const cartRow = singlePrice.parentElement.parentElement;
     const cartQuantityField = cartRow.querySelector (".cart-quantity-input");
     cartTotal += parseInt(singlePrice.innerHTML) * cartQuantityField.value;
    });
    const cartTotalElementSelect = document.querySelector('.cart-total-price');
    cartTotalElementSelect.innerHTML= `$ ${cartTotal.toFixed(2)
    }`
  }

  function bindAllCartQuantityInputFields() {
    const allCartInputFields = document.querySelectorAll(".cart-quantity-input");
    allCartInputFields.forEach(function (singleInputField) {
      singleInputField.removeEventListener("change", CartQuantityChangeHandler);
      singleInputField.addEventListener("change", CartQuantityChangeHandler);
    });
  }
  
  function CartQuantityChangeHandler(event) {
    const currentElement = event.target;
    if (currentElement.value <= 0) {
      currentElement.value = 1;
    }
  
    updateCartTotal();
  }
  
  purchaseBtn.addEventListener("click", purchaseBtnHandler);
  function purchaseBtnHandler (event){
    event.preventDefault();
  cartItemsElement.innerHTML = "" ;
  updateCartTotal();
  alert("you have purchase successfully");
  }

